---
weight: 500
toc: true
title: Deploy to kind
menu:
    docs:
        parent: kube
lead: Deploy kube-prometheus to Kubernets kind.
images: []
draft: false
description: Deploy kube-prometheus to Kubernets kind.
date: "2021-03-08T23:04:32+01:00"
---

---

Time to explain how!

Your chance of [**contributing**](https://github.com/prometheus-operator/kube-prometheus/blob/main/docs/deploy-kind.md)!
